<?php 
//Fy!s_G&z^k$}
	$koneksi = mysqli_connect("localhost","root","","dbdesacerdas"); 
	//$koneksi = mysqli_connect("localhost","root","","dlhkabci_sales"); 
	if (mysqli_connect_errno()){
		echo "Koneksi database gagal : " . mysqli_connect_error();
	}
?>