<?php
	$nm_file=$_GET['nm_file'];
?>
	
<!DOCTYPE html>
<html>
<head>
	<title><?php include "titel.php"; ?></title>
</head>
<body>


	<object data="<?php echo $nm_file; ?>" width="100%" height="700px"></object>


</body>
</html>